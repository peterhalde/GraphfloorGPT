// Direct check to force Teig matching
console.log('Forcing Teig duplicate detection...');

// Get all nodes
const response = await fetch('http://localhost:5000/api/nodes/approved');
const data = await response.json();

// Find Teig nodes
const teigNodes = data.nodes.filter(node => 
  node.name.toLowerCase().trim() === 'teig'
);

console.log(`Found ${teigNodes.length} Teig nodes:`);
teigNodes.forEach((node, i) => {
  console.log(`${i+1}. "${node.name}" - ID: ${node.id.substring(0,8)}...`);
});

if (teigNodes.length >= 2) {
  // Force create the duplicate candidate via SQL insertion
  console.log('Creating duplicate candidate directly...');
  
  const createResponse = await fetch('http://localhost:5000/api/duplicates/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ threshold: 1 })
  });
  
  console.log('Analysis started with threshold 1%');
} else {
  console.log('Not enough Teig nodes found!');
}