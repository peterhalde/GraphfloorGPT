// Quick debug script to find Teig nodes
const response = await fetch('http://localhost:5000/api/nodes/approved');
const data = await response.json();
const teigNodes = data.nodes.filter(node => node.name.toLowerCase().includes('teig'));
console.log('Teig nodes found:', teigNodes.length);
teigNodes.forEach((node, i) => {
  console.log(`${i+1}. ID: ${node.id}`);
  console.log(`   Name: "${node.name}"`);
  console.log(`   Type: ${node.type}`);
  console.log(`   Description: ${node.description}`);
  console.log('---');
});