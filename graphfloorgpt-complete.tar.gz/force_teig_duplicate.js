// Force create Teig duplicate candidate
const teigNode1 = "fa3c6fd2-afd0-4056-a7a2-33d94009e72a";  
const teigNode2 = "d9440437-864e-44db-84e2-380d1d6b5a5e";

console.log('Creating duplicate candidate for Teig nodes...');

const response = await fetch('http://localhost:5000/api/duplicates/candidates', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    nodeId1: teigNode1,
    nodeId2: teigNode2,
    similarityScore: "100",
    status: "pending"
  })
});

const result = await response.json();
console.log('Result:', result);